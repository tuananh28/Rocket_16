create definer = root@localhost trigger SubjectUpdateID
    before update
    on subject
    for each row
BEGIN
        UPDATE `StudentSubject`
        SET     SubjectID = NEW.ID
        WHERE   SubjectID = OLD.ID;
    end;

