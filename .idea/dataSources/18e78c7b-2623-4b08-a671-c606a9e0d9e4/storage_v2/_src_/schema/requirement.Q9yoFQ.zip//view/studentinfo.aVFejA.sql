create definer = root@localhost view studentinfo as
select `ss`.`StudentID`                                                                 AS `studentid`,
       `ss`.`SubjectID`                                                                 AS `subjectid`,
       `stu`.`Name`                                                                     AS `Name`,
       `stu`.`Age`                                                                      AS `Age`,
       (case `stu`.`Gender` when 1 then 'Female' when 0 then 'Male' else 'Unknown' end) AS `Gender`,
       `sub`.`Name`                                                                     AS `Subject Name`,
       `ss`.`Mark`                                                                      AS `Mark`,
       `ss`.`Date`                                                                      AS `Date`
from ((`requirement`.`studentsubject` `ss` join `requirement`.`student` `stu` on ((`stu`.`ID` = `ss`.`StudentID`)))
         join `requirement`.`subject` `sub` on ((`sub`.`ID` = `ss`.`SubjectID`)));

