create definer = root@localhost trigger StudentDeleteID
    before delete
    on student
    for each row
BEGIN
        DELETE
        FROM `StudentSubject`
        WHERE StudentID = OLD.ID;
    end;

