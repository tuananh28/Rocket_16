create definer = root@localhost trigger Ques_4
    before insert
    on sinhvien
    for each row
BEGIN
        DECLARE var_BirthSV SMALLINT;
        SELECT Namsinh INTO var_BirthSV
        FROM `SinhVien`
        WHERE NEW.Namsinh = var_BirthSV;
        IF(NEW.Namsinh <= 1900) THEN
            SIGNAL SQLSTATE '12345'
            SET MESSAGE_TEXT = 'năm sinh phải > 1900';
        end if;
    end;

