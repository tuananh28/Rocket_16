create definer = root@localhost view sinhvieninfo as
select `sv`.`MaSV`                                                           AS `MaSV`,
       `sv`.`HotenSV`                                                        AS `HotenSV`,
       (case when isnull(`dt`.`TenDT`) then 'Chưa có' else `dt`.`TenDT` end) AS `CASE WHEN TenDT IS NULL THEN 'Chưa có' ELSE TenDT END`
from ((`final_exam_2`.`sinhvien` `sv` left join `final_exam_2`.`huongdan` `hd` on ((`sv`.`MaSV` = `hd`.`MaSV`)))
         left join `final_exam_2`.`detai` `dt` on ((`dt`.`MaDT` = `hd`.`MaDT`)))
group by `sv`.`MaSV`, `sv`.`HotenSV`, `dt`.`TenDT`;

