create definer = root@localhost trigger Trg_InsertToSinhVien
    before insert
    on sinhvien
    for each row
BEGIN
        IF (NEW.NamSinh <= '1950')
        THEN
			SIGNAL SQLSTATE '12345'
            SET MESSAGE_TEXT = 'Moi ban kiem tra lai nam sinh. ';
		END IF;
	END;

